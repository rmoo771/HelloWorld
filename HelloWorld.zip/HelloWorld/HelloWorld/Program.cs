﻿// A Hello World program 
namespace HelloWorld
{
    using System;
    using System.Configuration;


    public interface IOutputWriter
    {
        void WriteLine(string txt);
    }


    public class ConsoleWrapper : IOutputWriter
    {
       
        public void WriteLine(string txt)
        {
            Console.WriteLine(txt);
           
        }
    }

    public class ConsoleWriter : IOutputWriter
    {
        public IOutputWriter Console { get; set; }

        public void WriteLine(string txt)
        {
            Console = new ConsoleWrapper();
            Console.WriteLine("You've written to the Console the following text: " + txt);
        }
    }

    public class DatabaseWriter : IOutputWriter
    {
        public IOutputWriter Console { get; set; }
        
        public void WriteLine(string txt)
        {
            Console = new ConsoleWrapper();
            Console.WriteLine("You've written to the Database the following text: " + txt);
        }
    }

    public class FileWriter : IOutputWriter
    {
        public IOutputWriter Console { get; set; }

        public void WriteLine(string txt)
        {
            Console = new ConsoleWrapper();
            Console.WriteLine("You've written to a File the following text: " + txt);

        }
    }

    public class Program
    {        

        public static void Main()
        {
            var value = ConfigurationManager.AppSettings["DataSource"]
                   .ToString();

            switch (value)
            {
                case "Console":
                    IOutputWriter consoleWriter = new ConsoleWriter();
                    WriteHelloWorld(consoleWriter);
                    break;

                case "Database":
                    IOutputWriter databaseWriter = new DatabaseWriter();
                    WriteHelloWorld(databaseWriter);
                    break;

                case "File":
                    IOutputWriter fileWriter = new FileWriter();
                    WriteHelloWorld(fileWriter);
                    break;

            }


        }

        public static void WriteHelloWorld(IOutputWriter console)
        {
            console.WriteLine("Hello World");
            Console.ReadKey();
        }

    }
}
